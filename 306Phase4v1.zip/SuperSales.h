#ifndef SUPERSALES_H
#define SUPERSALES_H

#include "SalesPerson.h"

class SuperSales : public SalesPerson {
public:
    using SalesPerson::SalesPerson;

    double calculateCommission() const override;
};

#endif // SUPERSALES_H
